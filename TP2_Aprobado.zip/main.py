from orquestadores import orquestador

def main ():
    orquestador()
main()